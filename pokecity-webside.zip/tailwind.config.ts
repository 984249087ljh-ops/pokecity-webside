import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        cream: "#F6EFE2",
        mango: "#D9824B",
        sun: "#E8B86B",
        basil: "#7F9C7A",
        mint: "#DDE7D7",
        ocean: "#79B7B7",
        salmon: "#E79D91",
        beige: "#EFE5D5",
        sky: "#D8DED8",
        ink: "#173428",
        forest: "#173428",
        sage: "#7F9C7A",
        stone: "#8B8C82",
        ivory: "#FBF5EA",
        apricot: "#D9824B"
      },
      boxShadow: {
        soft: "0 18px 55px rgba(23, 50, 43, 0.12)",
        lift: "0 18px 35px rgba(63, 166, 107, 0.22)"
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"]
      }
    }
  },
  plugins: []
};

export default config;
