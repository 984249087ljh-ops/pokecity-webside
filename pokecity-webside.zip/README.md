# POKE CITY Bolzano

Modern POKE CITY Bolzano website and visual bowl builder built with Next.js, TypeScript, App Router and Tailwind CSS.

The site is now structured as a premium Poke Bowl brand website plus takeaway preorder flow:

- `/` homepage with **Compila la tua Bowl**
- `/menu` visual menu board
- `/build-your-own` interactive bowl builder
- `/order` takeaway preorder form
- `/allergens` allergen reference
- `/about` brand page
- `/contact` location and contact page

## Run Locally

```bash
pnpm install
pnpm dev
```

Open:

```txt
http://localhost:3000
```

Production build:

```bash
pnpm build
```

## Menu Data

All editable menu data lives in:

```txt
data/pokeCityMenu.ts
```

Edit this file to change:

- bowl sizes
- prices
- included quantities
- extra pricing
- base options
- protein options
- ingredient options
- sauce options
- topping options
- allergen numbers
- item images

Pricing logic lives in:

```txt
lib/pricing.ts
```

## Bowl Size Rules

Current rules:

- Regular — 8,50€: 1 base, 1 proteina, 3 ingredienti, 2 salse, 1 topping
- Large — 11,00€: 1 base, 2 proteine, 4 ingredienti, 2 salse, 2 topping
- Extra Large — 13,50€: 1 base, 3 proteine, 5 ingredienti, 2 salse, 2 topping

Extra prices:

- Proteine: +2,00€
- Ingredienti: +0,50€
- Salse: +0,30€
- Topping: +0,30€

## Replace Images

Every menu option has an `image` field in `data/pokeCityMenu.ts`.

Recommended folders:

```txt
public/images/sizes
public/images/base
public/images/proteins
public/images/ingredients
public/images/sauces
public/images/toppings
public/images/placeholders
```

If an image fails to load, `SmartImage` falls back to:

```txt
public/images/placeholders/option-placeholder.jpg
```

Replace files with the same names to update the website without changing code. For final launch, replace placeholders with real POKE CITY food photography.

## Add A New Ingredient

Add a new item to the correct array in `data/pokeCityMenu.ts`, for example:

```ts
{
  slug: "new-item",
  name: "New Item",
  category: "ingredients",
  image: "/images/ingredients/new-item.jpg",
  allergens: []
}
```

Then add the image file under `public/images/ingredients`.

## Order Flow

`/build-your-own` saves the current bowl to localStorage:

```txt
pokeCityBowlSelection
```

`/order?custom=true` reads that selection, shows the bowl summary, total price and allergen reminder.

The current `handleSubmit()` is frontend-only. Later it can be connected to:

- WhatsApp message generation
- email
- API route
- database
- POS/order management system

## Main Components

- `Navbar`
- `Footer`
- `Hero`
- `BowlBuilder`
- `BowlBuilderSection`
- `BowlSizeCard`
- `BowlOptionCard`
- `BowlSummary`
- `AllergenBadge`
- `AllergenTable`
- `OrderForm`
- `MenuBoardSection`
- `SmartImage`
- `SectionHeading`
- `TakeawayCTA`
- `WaveDecoration`
- `LeafDecoration`

## Deploy To Vercel

1. Push the project to GitHub.
2. Import it in Vercel.
3. Use the default Next.js settings.
4. Build command: `pnpm build`.
5. Output: handled automatically by Next.js.

## Pre-Launch Checklist

- Replace placeholder menu images with real product photos.
- Confirm allergen numbers with the printed in-store menu.
- Confirm prices and extra pricing.
- Test `/build-your-own` on mobile.
- Submit a test order from `/order`.
- Decide whether order submission goes to WhatsApp, email or backend API.
- Add real Privacy Policy and Cookie Policy links.
- Confirm Google Maps listing and Instagram link.
